//MTG-OpenBoard Client

var mtgOpenBoard = angular.module('MTGOpenBoard',[/*'ui.bootstrap'*/]);
mtgOpenBoard.config(['$routeProvider',/*'$locationProvider',*/ function($routeProvider) {
  $routeProvider.when('/lobby', { templateUrl: 'src/views/lobby.html', controller: 'LobbyViewController' });
  $routeProvider.when('/userInfo', { templateUrl: 'src/views/userInfo.html', controller: 'UserInfoViewController' });
  $routeProvider.when('/deckCreator', { templateUrl: 'src/views/deckCreator.html', controller: 'DeckCreatorViewController' });
  $routeProvider.when('/logout', { redirectTo:'/' });
  $routeProvider.otherwise({redirectTo:'/lobby'});
  //$locationProvider.html5Mode(false);
}]);

var cardIDs = [];

var socket = io.connect('http://localhost:8008');
socket.on('connected', function(data) {
  console.log("SERVER: "+data.msg);
});
socket.on('searchResultImage', function(cardData) {
  //console.log("SERVER (searchResult): "+data);
  //<img src="data:image/png;base64,xxxxxxxxxxxxxxxxxx" />
  var data = JSON.parse(cardData);
  cardIDs.push(data.id);
  console.log("CONTENTS OF ID ARRAY:");
  console.log(cardIDs);
  var imgSrc ="data:image/jpeg;base64,"+data.imgData;
  var imgElem = $(document.createElement('img')).attr({'src':imgSrc});
  $("#cardImgContainer").empty().append(imgElem);
  /*var card = $(document.createElement('div')).attr({'class':'cardPopup'});//.css({'width':});
  var cardImg = $(document.createElement('img')).attr({'src':imgSrc});
  $(card).append(cardImg);
  $(card).click(function() {
    $(this).remove();
  });
  var w = $(cardImg).width();
  var h = $(cardImg).height();
  console.log("CARD W="+w+", H="+h);
  var left = $('#mainContainer').parent().width()/2-w/2;
  var top = $('#mainContainer').parent().height()/2-h/2;
  $(card).css({'left':left,'top':top});
  $('#mainContainer').append(card);*/
});

function fetchCardByName(cardName) {
  console.log("Starting search for: "+cardName);
  socket.emit('searchRequest',{card:{name:cardName}});
}
function fetchCardByURL(url) {
  console.log("Starting search for: "+url);
  socket.emit('searchRequest',{card:{url:url}});
}


function TopAreaController($scope, $location) {
  $scope.user = {nickname : "Anonyymi"};
  $scope.getUserNickName = function() {
    return $scope.user.nickname;
  }
  $scope.logout = function() {
    console.log("LOGOUT CLICKED");
    $location.path("/logout");
  }
}

function BottomAreaController($scope) {
  $scope.users = { count: 1 };
}

function MainViewTabController($scope) {
  $scope.tabs = [ { link: '#/lobby', label: 'Chat Lobby' },
                  { link: '#/userInfo', label: 'User Info' },
                  { link: '#/deckCreator', label: 'Deck Creator' }];

  $scope.selectedTab = $scope.tabs[0];
  $scope.setSelectedTab = function(tab) {
    $scope.selectedTab = tab;
  }
  $scope.getTabClass = function(tab) {
    if($scope.selectedTab == tab) {
      return "active";
    }
    else {
      return "";
    }
  }
}

function LobbyViewController($scope) {

}
function UserInfoViewController($scope) {

}
function DeckCreatorViewController($scope) {
  var currentCard = { id: 0, name: "", details: "" };
  function updateCardImage(data) {
  
  } 
  function updateCardInfo(info) {
    currentCard.id = info.id;
    currentCard.name = info.name;
    currentCard.details = info.details;
  }
  updateCardInfo({ id: 666, name: "Default Name", details: "This is the placeholder details description area where rules of the card are explained." });
}

$(document).ready(function() {
	console.log("Client ready.");

  //TODO: ANSWAH FOR ROUTING: http://stackoverflow.com/questions/16872191/angularjs-ui-bootstrap-tabs-that-support-routing

  jQuery.event.props.push('dataTransfer');

  $('#addCard').click(function(e) {
    if($("#cardImgContainer").has('img').length>0) {
      var smallerImg = $("#cardImgContainer > img").clone();
      var w = $("#cardImgContainer > img").width();//$(smallerImg).width();
      var h = $("#cardImgContainer > img").height();//$(smallerImg).height();
      console.log("IMAGE H="+h+", W="+w+", ELEM LEN="+smallerImg.length);
      $(smallerImg).width(w/2);
      $(smallerImg).height(h/2);    
      $('#cardsContainer').append(smallerImg);
    }
    else {
      alert("NO CARD PRESENT");
    }
  });

  $('#clearDeck').click(function(e) {
    $('#cardsContainer').empty();
    cardIDs.length = 0;
  });

  $('#cardImgContainer').bind('dragenter', function(event) { event.stopPropagation(); event.preventDefault(); });
  $('#cardImgContainer').bind('dragexit', function(event) { event.stopPropagation(); event.preventDefault(); });
  $('#cardImgContainer').bind('dragover', function(event) { event.stopPropagation(); event.preventDefault(); });
  $('#cardImgContainer').bind('drop', function(event) {
    console.log(">>>>>>>>FILE DROPPED!");
    //event.stopImmediatePropagation();
    event.stopPropagation();
    event.preventDefault();    
    var imageUrl = event.dataTransfer.getData('URL');
    fetchCardByURL(imageUrl);
    return true;
  });


  $("#startSearch").click(function() {
    var cardName = $("#cardNameInput").attr('value');
    if(cardName.length>0) {
      fetchCardByName(cardName);
    }
    else {
      console.log("You needs to provide the card name for searching!");
    }
  });

});
