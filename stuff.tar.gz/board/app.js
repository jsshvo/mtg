//MTG-OpenBoard Main App

var express = require('express');
var app = express();
var https = require('https');
var http = require('http');
var fs = require('fs');
var jwt = require('jsonwebtoken');

var appServer = require('./js/server.js');
var appServerStarted = false;

app.use(express.logger());
app.use(express.bodyParser());

app.configure(function() {
	app.use('/js', express.static(__dirname + '/js'));
	app.use('/css', express.static(__dirname + '/css'));
	app.use('/src/img', express.static(__dirname + '/src/img'));
  app.use('/src/views', express.static(__dirname + '/src/views'));
});

var k = fs.readFileSync(__dirname +'/key/key.pem').toString();
var c = fs.readFileSync(__dirname +'/key/cert.pem').toString();

var options = {key: k, cert: c};
var webServer = http.createServer(app);
webServer.listen(4004);
var secureWebServer = https.createServer(options, app);
secureWebServer.listen(8008);

/**
http://stackoverflow.com/questions/10697660/force-ssl-with-expressjs-3
http://stackoverflow.com/questions/7450940/automatic-https-connection-redirect-with-node-js-express
http://stackoverflow.com/questions/18250134/express-node-js-using-https-and-http
**/

/*app.use(function(req, res, next) {
  if(!req.secure) {
    return res.redirect(['https://', req.get('Host'), req.url].join(''));
  }
  next();
});*/

/*function requireHTTPS(req, res, next) {
  if(!req.secure) {
    return res.redirect('https://' + req.get('host') + req.url);
  }
  next();
}
app.use(requireHTTPS);*/

app.get('*', function(req, res, next) {
  if(!req.secure) {
    var parts = req.get('Host').split(":");
    var host = parts[0]+":"+(8008).toString();
    res.redirect(301, ['https://', host, req.url].join(''));
  }
  else {
    next();
  }
});

app.get('/', function(req, res, next) {
  res.sendfile('index.html');
});

appServer.start(webServer);
appServer.on('started', function() {
  if(!appServerStarted) {
    appServerStarted = true;
    console.log("APP: AppServer started!");
    appServer.on('error', function(msg) {
      console.log("APP: ERROR: "+msg);
      if(appServerStarted) {
        appServer.stop();
      }
    });
  }
  else {
    console.log("APP: AppServer ALREADY started!");
  }
});
appServer.on('stopped', function() {
  appServerStarted = false;
  console.log("APP: AppServer stopped!");
});

//TODO: SHOULD THIS AND OTHER REST-REQs BE HANDLED BY COMPONENT SPECIFIC CONTROLLER (which in turn calls this for example)?
app.post('/home', function(req, res) {
  console.log("LOGIN ATTEMPT APPEARETH");

  //HOW IMA GETTIN USER INPHO HERE?

  console.log("UNAME="+req.uname);
  console.log("PWD="+req.pwd);

	var succ = true;
	if(succ) {
		console.log("Login attempt SUCCEEDED => home.html");
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
		res.sendfile('src/views/home.html');
	}
	else {
		console.log("Login attempt FAILED => index.html");
	  res.redirect('/');
	}
});

