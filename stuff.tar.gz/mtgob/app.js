//###ZE MAIN APP

var express = require('express');
var app = express();
var http = require('http');

var logger = require('morgan');
var bodyParser = require('body-parser');

app.use(logger());
app.use(bodyParser());
app.use('/js', express.static(__dirname + '/js'));
app.use('/css', express.static(__dirname + '/css'));
app.use('/rsc/img', express.static(__dirname + '/rsc/img'));
app.use('/rsc/views', express.static(__dirname + '/rsc/views'));

var webServer = http.createServer(app);
webServer.listen(4004);

app.get('/', function(req, res, next) {
  res.sendfile('index.html');
});

app.post('/create_account', function(req, res, next) {
  /*res.sendfile('index.html');*/
  console.log("CREATE ACCOUNT REQUEST");
  console.log(req);
});
