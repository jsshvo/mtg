var mtgOB_app = angular.module('MTGOB_app',[]);

function MainAppController($scope) {
  
}
