var mtgOB_login = angular.module('MTGOB_login',['ui.bootstrap','ngAnimate']);

function LoginController($scope) {
  $scope.show_create_account = false;
  $scope.createAccountLink = "No account yet?";
  $scope.toggleCreateAccountView = function() {
    console.log("CREATE ACCOUNT LINK CLICKED");
    $scope.show_create_account = !$scope.show_create_account;
    $scope.createAccountLink = $scope.show_create_account ? "Create new account:" : "No account yet?";
  }
}
