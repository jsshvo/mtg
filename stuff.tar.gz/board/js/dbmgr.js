var util = require('util');
var EventEmitter = require('events').EventEmitter;

var DBManager = function() {

	if(DBManager._instance) {
    return DBManager._instance;
  }
	DBManager._instance = this;

  var mongoose = require("mongoose");
	var db;
	var dbAddr = 'mongodb://localhost/openboard';
  //mongoose.set('debug', true);

  var gamesHistory = mongoose.Schema({
    startTime: { type: Number },
    endTime: { type: Number },
    winner: { userId: Number, deckId: Number },
    loser: { userId: Number, deckId: Number }
  },
  {
    collection: "gamesHistory"
  });

	var profileSchema = mongoose.Schema({
    //TODO: Explicitly defined id needed
		userName: { type: String },
		passWord: { type: String }, //TODO: CHECK CORRECT TYPE
    nickName: { type: String },
		email: { type: String },
		profileCreated: { type: Number, default: 0 },
		lastLogged: { type: Number, default: 0 }
	},
  {
		collection: "profiles"
	});

  var deckSchema = mongoose.Schema({
    profileId: { type: mongoose.Schema.Types.ObjectId }, //The creator/owner of this deck
    name: { type: String, default: "" },
    isPublic: { type: Boolean, default: false },
    isLocal: { type: Boolean, default: false }, //TODO: if true, cards are stored to local storage or sumthing.... THINK THIS OVER XD
    cardIds: { type: Array, default: [] } //TODO: populate with gatherer cardIDs or if deck is local, with X (yet to be decided) 
    //TODO: Also implement some getter for deck colors
  },
  {
    collection: "decks"
  });

  var prefSchema = mongoose.Schema({
    profileId: { type: mongoose.Schema.Types.ObjectId }, //The creator/owner of these preferences
    isPublic: { type: Boolean, default: false }, //WITH THIS WE CAN CREATE READYMADE PREFS FOR EXAMPLE FOR MOBILE-LAYOUTS
    //TODO: Add user desired settings, saved board layout, etc...
  },
  {
    collection: "preferences"
  });

	/*var cardSchema = mongoose.Schema({
		values: { type: mongoose.Schema.Types.Mixed }
	},{
		collection: "params"
	});*/

	var profileModel = mongoose.model("profileModel", profileSchema);
	var deckModel = mongoose.model("deckModel", deckSchema);
	var prefModel = mongoose.model("prefModel", prefSchema);
	//var cardModel = mongoose.model("cardModel", cardSchema);


  this.ready = function() {
    var dbReady = false;
    if (db && db !== undefined) dbReady = db.readyState == 1; //1 stands for "connected"
    return dbReady;
  };

  this.getState = function() {
    return (db && db !== undefined) ? db.readyState : -1;
  };

  this.connect = function() {
    mongoose.connect(dbAddr, {
      server: {
        auto_reconnect: false
      }
    });
    db = mongoose.connection;
    var self = this;

    db.on('error', function(err) {
      self.emit('error', err);
    });

    db.on('connected', function() {
      self.emit('connected');
    });

    db.on('disconnected', function() {
      dbReady = false;
      self.emit('disconnected');
    });

    db.once('open', function() {
      logger.debug({
        Module: "DBManager",
        FunctionName: "connect",
        Message: "DB OPENED, pending requests: " + pendingRequests.length
      });
      dbReady = true;
      self.emit('opened');
      if (pendingRequests.length > 0)
        processNext();
    });
  }; //end of connect

  this.disconnect = function(callback) {
    db.close();
    mongoose.disconnect(function() {
      if (typeof callback == "function")
        callback();
    });
  };

};
util.inherits(DBManager, EventEmitter);

DBManager.getInstance = function () {
	return DBManager._instance || new DBManager();
}

module.exports = DBManager;
